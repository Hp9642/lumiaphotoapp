require('dotenv').config();

const fs = require('fs');
const path = require('path');

const accountName   = process.env.AZ_STORAGE_ACCOUNT_NAME;

let BlobServiceClient, BlockBlobClient, DefaultAzureCredential;
let getTranscodedBlobName, moveTranscodedAsset, transcodeJobCompleted, transcodeVideo;

if (accountName) {
    const azureStorage = require("@azure/storage-blob");
    BlobServiceClient = azureStorage.BlobServiceClient;
    BlockBlobClient = azureStorage.BlockBlobClient;
    DefaultAzureCredential = require("@azure/identity").DefaultAzureCredential;
    
    const transcode = require('../modules/transcode.js');
    getTranscodedBlobName = transcode.getTranscodedBlobName;
    moveTranscodedAsset = transcode.moveTranscodedAsset;
    transcodeJobCompleted = transcode.transcodeJobCompleted;
    transcodeVideo = transcode.transcodeVideo;
}

const containerName = process.env.AZ_STORAGE_CONTAINER_NAME;
const accountUrl    = `https://${accountName}.blob.core.windows.net`;
const containerUrl  = `${accountUrl}/${containerName}`;
const imageCdnUrl   = process.env.IMAGE_CDN_BASE_URL;

// Database and path configuration
const db = require('../db/database');
const dataDir = path.join(__dirname, '..', 'data', 'events');

// Helper to get event directory
function getEventDir(eventId) {
    if (!eventId) throw new Error("Event ID required");
    const dir = path.join(dataDir, eventId);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        fs.mkdirSync(path.join(dir, 'original'), { recursive: true });
        fs.mkdirSync(path.join(dir, 'video_thumbnails'), { recursive: true });
    }
    return dir;
}

// ─── Local GET Photos ─────────────────────────────────────────────────────────
function localGetPhotos(req, res) {
    const eventId = req.query.eventId || req.headers['x-event-id'];
    if (!eventId) return res.status(400).json({ error: 'Event ID is required' });

    try {
        let pageSize = parseInt(req.query.pageSize) || 24;
        let startIndex = parseInt(req.query.pageMarker) || 0;
        let moderatedOnly = req.query.moderatedOnly === 'true';

        let sql = 'SELECT * FROM photos WHERE event_id = ?';
        let countSql = 'SELECT COUNT(*) as count FROM photos WHERE event_id = ?';
        let params = [eventId];

        if (moderatedOnly) {
            sql += ' AND is_approved = 1';
            countSql += ' AND is_approved = 1';
        }

        sql += ' ORDER BY uploaded_at DESC LIMIT ? OFFSET ?';
        let pageParams = [...params, pageSize, startIndex];

        db.all(
            sql,
            pageParams,
            (err, rows) => {
                if (err) return res.status(500).json({ error: 'Database error' });

                db.get(countSql, params, (err, countRow) => {
                    const total = countRow ? countRow.count : 0;
                    
                    let nextPage = (startIndex + pageSize < total) ? (startIndex + pageSize).toString() : "";
                    let done = (nextPage === "");

                    let files = rows.map(row => {
                        // Build a URL using the static file-serving route
                        const baseFileUrl = `/api/photos/download/${eventId}/${row.filename}`;
                        
                        let responseItem = {
                            name: row.filename,
                            url: baseFileUrl,
                            contentType: row.content_type,
                            metaTags: row.meta_tags,
                            peopleTags: row.people_tags,
                            note: row.note || "",
                            uploadedAt: row.uploaded_at,
                            uploaderName: row.uploader_name,
                            guestEmail: row.guest_email || "",
                            isApproved: row.is_approved
                        };

                        if (row.content_type && row.content_type.startsWith('video')) {
                            const thumbFilename = row.filename
                                .replace(/\.[^\.]+$/, '.jpg')
                                .replace(/^original\//, 'video_thumbnails/');
                            responseItem.thumbnail = `/api/photos/download/${eventId}/${thumbFilename}`;
                            responseItem.transcodedUrl = baseFileUrl;
                        } else {
                            responseItem.thumbnail = baseFileUrl;
                        }
                        return responseItem;
                    });

                    res.status(200).send({ files, nextPage, done, total });
                });
            }
        );
    } catch (error) {
        console.error("Local GET photos failed:", error);
        res.status(500).send({ message: 'Internal Server Error' });
    }
}

// ─── Local POST Create Photo ──────────────────────────────────────────────────
function localCreatePhotos(req, res) {
    const eventId = req.query.eventId || req.headers['x-event-id'];
    if (!eventId) return res.status(400).json({ error: 'Event ID is required' });

    try {
        // Check shot limit BEFORE accepting the upload
        db.get('SELECT shot_limit, enable_upload, enable_moderation FROM events WHERE id = ?', [eventId], (err, event) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            if (!event) return res.status(404).json({ error: 'Event not found' });
            if (parseInt(event.enable_upload) !== 1) {
                return res.status(405).json({ error: 'Uploads are currently disabled for this event' });
            }

            // Count existing photos for this event
            db.get('SELECT COUNT(*) as count FROM photos WHERE event_id = ?', [eventId], (err, countRow) => {
                if (err) return res.status(500).json({ error: 'Database error' });
                
                const photoCount = countRow ? countRow.count : 0;
                if (event.shot_limit > 0 && photoCount >= event.shot_limit) {
                    return res.status(429).json({ 
                        error: 'Shot limit reached',
                        details: `This event has reached its limit of ${event.shot_limit} photos.`
                    });
                }

                // Proceed with file write
                const eventDir = getEventDir(eventId);
                const contentType = req.headers["content-type"];
                const extension = getExtensionFromContentType(contentType);
                
                const rawTargetFilename = (req.query.targetFilename || `photo_${Date.now()}`)
                    .replace(/^original\//i, '')
                    .replace(/^video_thumbnails\//i, '');
                const nakedFilename = rawTargetFilename.split(".")[0];

                const isThumb = (req.query.targetFilename || '').startsWith('video_thumbnails/');
                const subdir = isThumb ? 'video_thumbnails' : 'original';
                const bucketFilename = `${subdir}/${nakedFilename}.${extension}`;
                
                const filePath = path.join(eventDir, bucketFilename);
                
                // Ensure subdir exists
                const subdirPath = path.join(eventDir, subdir);
                if (!fs.existsSync(subdirPath)) fs.mkdirSync(subdirPath, { recursive: true });

                const writeStream = fs.createWriteStream(filePath);
                req.pipe(writeStream);

                writeStream.on('finish', () => {
                    const uploader = req.headers["x-meta-uploader"] || "Guest";
                    const guestEmail = req.headers["x-meta-email"] || "";
                    const guestNote = req.headers["x-meta-note"] ? decodeURIComponent(req.headers["x-meta-note"]) : "";
                    const metaTags = JSON.stringify(["uploader:" + uploader]);
                    
                    const isApproved = event.enable_moderation === 1 ? 0 : 1;

                    if (!isThumb) {
                        db.run(
                            'INSERT INTO photos (event_id, filename, content_type, uploader_name, guest_email, note, meta_tags, is_approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                            [eventId, bucketFilename, contentType, uploader, guestEmail, guestNote, metaTags, isApproved],
                            (err) => {
                                if (err) console.error("Error saving photo to DB:", err);
                            }
                        );
                    }

                    res.status(201).send({ message: 'OK', details: 'Files uploaded successfully!' });
                });

                writeStream.on('error', (error) => {
                    console.error("Write stream failed:", error);
                    res.status(400).send({ message: 'Bad Request' });
                });
            });
        });
        
    } catch(error) {
        console.error("Local upload failed:", error);
        res.status(500).send({ message: 'Internal Server Error' });
    }
}

// ─── Local PATCH Photos (update tags/note) ────────────────────────────────────
function localPatchPhotos(req, res) {
    const eventId = req.query.eventId || req.headers['x-event-id'];
    if (!eventId) return res.status(400).json({ error: 'Event ID is required' });

    const { files } = req.body;
    if (!files || !Array.isArray(files)) {
        return res.status(400).json({ error: 'files array is required' });
    }

    let outcomes = { completed: [], failed: [] };
    let pending = files.length;

    if (pending === 0) return res.status(200).json({ message: 'OK', outcomes });

    files.forEach(file => {
        if (!file.name || !file.metadata) {
            outcomes.failed.push(file);
            if (--pending === 0) return res.status(200).json({ message: 'OK', outcomes });
            return;
        }

        const { metaTags, peopleTags, isApproved } = file.metadata;
        db.run(
            'UPDATE photos SET meta_tags = COALESCE(?, meta_tags), people_tags = COALESCE(?, people_tags), is_approved = COALESCE(?, is_approved) WHERE event_id = ? AND filename = ?',
            [
                metaTags !== undefined ? metaTags : null,
                peopleTags !== undefined ? peopleTags : null,
                isApproved !== undefined ? isApproved : null,
                eventId,
                file.name
            ],
            function(err) {
                if (err) {
                    console.error('Patch photo error:', err);
                    outcomes.failed.push(file);
                } else {
                    outcomes.completed.push(file);
                }
                if (--pending === 0) {
                    res.status(200).json({ message: 'OK', details: 'Photos updated', outcomes });
                }
            }
        );
    });
}

// ─── Local DELETE Photos ──────────────────────────────────────────────────────
function localDeletePhotos(req, res) {
    const eventId = req.query.eventId || req.headers['x-event-id'];
    if (!eventId) return res.status(400).json({ error: 'Event ID is required' });

    const { files } = req.body;
    if (!files || !Array.isArray(files)) {
        return res.status(400).json({ error: 'files array is required' });
    }

    let outcomes = { completed: [], failed: [] };
    let pending = files.length;

    if (pending === 0) return res.status(200).json({ message: 'OK', outcomes });

    const eventDir = path.join(dataDir, eventId);

    files.forEach(file => {
        if (!file.name) {
            outcomes.failed.push(file);
            if (--pending === 0) return res.status(200).json({ message: 'OK', outcomes });
            return;
        }

        // Sanitize path to prevent directory traversal
        const safeName = path.normalize(file.name).replace(/^(\.\.(\/|\\|$))+/, '');
        const filePath = path.join(eventDir, safeName);

        // Delete physical file
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }
            // Also try to delete video thumbnail if it's a video
            const thumbPath = filePath
                .replace(/^original\//, 'video_thumbnails/')
                .replace(/\.[^.]+$/, '.jpg');
            if (fs.existsSync(thumbPath)) {
                fs.unlinkSync(thumbPath);
            }
        } catch(e) {
            console.error('File delete error:', e);
        }

        // Delete from DB
        db.run(
            'DELETE FROM photos WHERE event_id = ? AND filename = ?',
            [eventId, safeName],
            function(err) {
                if (err) {
                    console.error('DB delete error:', err);
                    outcomes.failed.push(file);
                } else {
                    outcomes.completed.push(file);
                }
                if (--pending === 0) {
                    res.status(200).json({ message: 'OK', details: 'Photos deleted', outcomes });
                }
            }
        );
    });
}

// ─── Azure GET ────────────────────────────────────────────────────────────────
async function getPhotos(req, res) {
    if (!accountName) {
        return localGetPhotos(req, res);
    }

    const blob = new BlobServiceClient(
        accountUrl,
        new DefaultAzureCredential()
    );

    const container = blob.getContainerClient(containerName);

    let pageSizeFromQuery = parseInt(req.query.pageSize);
    let pageSize = ((pageSizeFromQuery > 0) ? pageSizeFromQuery : 1);
    let pageMarker = req.query.pageMarker || undefined;

    let blobOpts = { 
        prefix: 'original',
        includeMetadata: true
    };

    let pageOpts = { 
        maxPageSize: pageSize,
        continuationToken: pageMarker
    };

    try {
        let page = await container.listBlobsFlat(blobOpts).byPage(pageOpts).next();

        let items = page.value.segment.blobItems;
        let marker = page.value.continuationToken;
        let done = (marker === '');

        let files = [];
        let promises = [];

        items.forEach((item, index) => {
            let promise = new Promise(async (resolve) => {
                const contentType = item.properties.contentType;
                const baseUrl = (contentType.split('/')[0] === 'image' && imageCdnUrl) ? 
                    imageCdnUrl : containerUrl;
                let transcodedUrl;
                if(contentType.split('/')[0] === 'video') {
                    transcodedUrl = await getTranscodedUrl(item);
                }
                const { metaTags, peopleTags, note } = item.metadata;
                files[index] = {
                    url: `${baseUrl}/${item.name}`,
                    transcodedUrl,
                    thumbnail: getThumbnailUrl(item),
                    contentType,
                    metaTags,
                    peopleTags,
                    note: note || ""
                };
                resolve(true);
            });
            promises.push(promise);
        });
        
        await Promise.all(promises);
        res.status(200).send({ files, nextPage: marker, done });
        
    } catch(error) {
        res.status(500).send({
            message: 'Internal Server Error',
            details: 'Could not retrieve photos.'
        });
    }
}

// ─── Azure POST ───────────────────────────────────────────────────────────────
function createPhotos(req, res) {
    if (!accountName) {
        return localCreatePhotos(req, res);
    }

    try {
        const contentType = req.headers["content-type"];
        const extension = getExtensionFromContentType(contentType);
        const nakedFilename = req.query.targetFilename.split(".")[0];
        const bucketFilename = `${nakedFilename}.${extension}`; 
        const bucketUrl = `${containerUrl}/${bucketFilename}`;

        const blockBlob = new BlockBlobClient(bucketUrl, new DefaultAzureCredential());
        const uploader = req.headers["x-meta-uploader"] || "Guest";
        const guestNote = req.headers["x-meta-note"] ? decodeURIComponent(req.headers["x-meta-note"]) : "";

        blockBlob.uploadStream(
            req, 
            8 * 1024 * 1024,
            2,
            { 
                blobHTTPHeaders: { blobContentType: contentType },
                metadata: {
                    metaTags: JSON.stringify(["uploader:" + uploader]),
                    peopleTags: "[]",
                    note: guestNote
                }
            }
        ).then(() => {
            if(contentType.split('/')[0] === 'video') {
                transcodeVideo(bucketUrl, 'default').then((job) => {
                    if(!job) throw new Error('Failed to create transcode job');
                    blockBlob.setMetadata({ transcodeJobName: job.name, transcodeTransformName: 'default' });
                }).catch(console.error);
            }
            res.status(201).send({ message: 'OK', details: 'Files uploaded successfully!' });
        }).catch(() => {
            res.status(400).send({ message: 'Bad Request', details: 'Could not upload files.' });
        });
        
    } catch(error) {
        res.status(500).send({ message: 'Internal Server Error', details: 'Could not upload photos.' });
    }
}

// ─── Azure PATCH ──────────────────────────────────────────────────────────────
function patchPhotos(req, res) {
    if (!accountName) {
        return localPatchPhotos(req, res);
    }
    // Azure implementation unchanged
    if(!req.body.files) return res.status(400).send({ message: 'Bad Request', details: 'No files supplied.' });
    let outcomes = { completed: [], failed: [...req.body.files] };
    if(req.body.password !== process.env.WPA_MANAGE_PASSWORD) {
        return res.status(401).send({ message: 'Unauthorized', details: 'Password does not match.', outcomes });
    }
    let patchOperations = [];
    outcomes.failed.forEach((file, i) => {
        const blockBlob = new BlockBlobClient(`${containerUrl}/${file.name}`, new DefaultAzureCredential());
        if(!file.metadata) return;
        let patchOp = blockBlob.setMetadata(file.metadata).then((result) => {
            if(!result.errorCode) { outcomes.completed.push(file); delete outcomes.failed[i]; }
        }).catch(console.error);
        patchOperations.push(patchOp);
    });
    Promise.all(patchOperations).then(() => {
        outcomes.failed = outcomes.failed.flat();
        res.status(200).send({ message: 'OK', details: 'All photos updated', outcomes });
    }).catch(() => {
        res.status(500).send({ message: 'Internal Server Error', details: 'Not all files were updated', outcomes });
    });
}

// ─── Azure DELETE ─────────────────────────────────────────────────────────────
function deletePhotos(req, res) {
    if (!accountName) {
        return localDeletePhotos(req, res);
    }
    if(!req.body.files) return res.status(400).send({ message: 'Bad Request', details: 'No files supplied.' });
    let outcomes = { completed: [], failed: [...req.body.files] };
    if(req.body.password !== process.env.WPA_MANAGE_PASSWORD) {
        return res.status(401).send({ message: 'Unauthorized', details: 'Password does not match.', outcomes });
    }
    let container;
    try {
        const blob = new BlobServiceClient(accountUrl, new DefaultAzureCredential());
        container = blob.getContainerClient(containerName);
    } catch(error) {
        return res.status(500).send({ message: 'Internal Server Error', details: 'Not all files were deleted', outcomes });
    }
    let deleteOperations = [];
    outcomes.failed.forEach((file, i) => {
        let deleteOp = container.deleteBlob(file.name).then((result) => {
            if(!result.errorCode) { outcomes.completed.push(file); delete outcomes.failed[i]; }
        }).catch(console.error);
        deleteOperations.push(deleteOp);
    });
    Promise.all(deleteOperations).then(() => {
        outcomes.failed = outcomes.failed.flat();
        res.status(200).send({ message: 'OK', details: 'All photos deleted', outcomes });
    }).catch(() => {
        res.status(500).send({ message: 'Internal Server Error', details: 'Not all files were deleted', outcomes });
    });
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function getExtensionFromContentType(contentType) {
    if (!contentType) return 'jpg';
    const suffix = contentType.split("/")[1];
    switch(suffix) {
        case 'heic': return 'HEIC';
        case 'jpeg': return 'jpg';
        case 'quicktime': return 'mov';
        default: return suffix;
    }
}

function getThumbnailUrl(item) {
    const baseUrl = (imageCdnUrl || containerUrl);
    let url;
    switch(item.properties.contentType.split('/')[0]) {
        case 'image':
            url = `${baseUrl}/${item.name}`;
            break;
        case 'video': 
            let thumbFilename = item.name
                .replace(/[^\.]*$/, 'jpg')
                .replace(/^original\//gi, 'video_thumbnails/');
            url = `${baseUrl}/${thumbFilename}`;
            break;
        default: break;
    }
    return url;
}

async function getTranscodedUrl(item) {
    return new Promise(async (resolve) => {
        if(!item.metadata) return resolve();
        const { transcodeJobName, transcodeTransformName, transcodedUrl } = item.metadata;
        if(transcodedUrl) return resolve(transcodedUrl);
        if(transcodeTransformName && transcodeJobName) {
            const jobComplete = await transcodeJobCompleted(transcodeTransformName, transcodeJobName); 
            if(jobComplete) {
                moveTranscodedAsset(transcodeJobName, item.name);
                return resolve(`${containerUrl}/${getTranscodedBlobName(item.name)}`);
            }
        }
        resolve();
    });
}
  
module.exports = { 
    getPhotos,
    createPhotos,
    patchPhotos,
    deletePhotos
};