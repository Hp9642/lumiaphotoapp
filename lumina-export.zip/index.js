
/* Setup Express */
const express = require('express');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');
const os = require('os');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const app = express();

// Production Security & Logging
app.use(helmet({
    contentSecurityPolicy: false, // Disabled for inline scripts/styles during development
}));
app.use(morgan('tiny'));

// Rate limiting for API routes
const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 200, // Limit each IP to 200 requests per windowMs
    message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', apiLimiter);

app.use(compression());
app.use(express.json());
app.use(cookieParser());
const port = process.env.PORT || 3000;

// Initialize Database
require('./db/database');

/* Load API Methods */
const authAPI = require('./api/auth.js');
const eventsAPI = require('./api/events.js');
const photosAPI = require('./api/photos.js');
const downloadPhotosAPI = require('./api/downloadPhotos.js');
const db = require('./db/database');

app.use('/api/auth', authAPI);
app.use('/api/events', eventsAPI);

/* Helper: Get local LAN IP for QR code generation */
function getLanIp() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return 'localhost';
}

/* Serve static files from the public folder */
app.use(express.static('public', { index: false }));

/* Route homepage */
app.get('/', (req, res) => {
    const redirectSetting = process.env.WPA_INDEX_REDIRECT || "index";
    switch(redirectSetting) {
        case 'upload':   return res.redirect('/upload');
        case 'download': return res.redirect('/download');
        case 'view':     return res.redirect('/view');
        default:         return res.sendFile(__dirname + '/public/index.html');
    }
});

/* ─── Page Routes ─────────────────────────────────────────────── */

const NO_CACHE = 'no-store, no-cache, must-revalidate';

app.get('/portal', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/portal.html');
});

app.get('/pricing', (req, res) => {
    res.sendFile(__dirname + '/public/pricing.html');
});

app.get('/upload', (req, res) => res.redirect('/'));

app.get('/:eventId/upload', (req, res) => {
    // Validate event exists before serving the camera page
    const eventId = req.params.eventId.toUpperCase();
    db.get('SELECT id, enable_upload FROM events WHERE id = ?', [eventId], (err, event) => {
        if (err || !event) {
            return res.redirect('/?error=invalid_event');
        }
        res.setHeader('Cache-Control', NO_CACHE);
        res.sendFile(__dirname + '/src/pages/upload.html');
    });
});

app.get('/:eventId/download', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/download.html');
});

app.get('/:eventId/view', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/view.html');
});

app.get('/:eventId/manage', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/manage.html');
});

app.get('/:eventId/moderate', (req, res) => {
    res.sendFile(__dirname + '/src/pages/moderate.html');
});

// Thank you page
app.get('/:eventId/thankyou', (req, res) => {
    res.sendFile(__dirname + '/src/pages/thankyou.html');
});

app.get('/:eventId/slideshow', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/slideshow.html');
});

app.get('/people/', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/people.html');
});

app.get('/tag/', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/tag.html');
});

app.get('/delete/', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/delete.html');
});

app.post('/delete/', (req, res) => {
    res.setHeader('Cache-Control', NO_CACHE);
    res.sendFile(__dirname + '/src/pages/delete.html');
});

/* ─── API Routes ──────────────────────────────────────────────── */

/* API health check */
app.get('/api', (req, res) => {
    res.status(200).json({ status: 200, message: 'OK', details: 'API available' });
});

/* Server info for QR code generation (LAN IP) */
app.get('/api/server-info', (req, res) => {
    const lanIp = getLanIp();
    res.json({
        lanIp,
        port,
        baseUrl: `http://${lanIp}:${port}`
    });
});

/* Config API - GET event config for guests */
app.get('/api/config', (req, res) => {
    const eventId = (req.query.eventId || '').toUpperCase();
    if (!eventId) return res.status(400).json({ error: 'Event ID is required' });

    db.get('SELECT * FROM events WHERE id = ?', [eventId], (err, event) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        if (!event) return res.status(404).json({ error: 'Event not found' });
        res.status(200).json({
            eventName: event.name,
            countdownTarget: event.release_time || "",
            shotLimit: event.shot_limit,
            enableUpload: event.enable_upload,
            enableDownload: event.enable_download,
            customMessage: event.custom_message || "",
            enableModeration: event.enable_moderation || 0,
            monetizationTier: event.monetization_tier || 'free',
            sponsorLink: event.sponsor_link || "",
            sponsorText: event.sponsor_text || ""
        });
    });
});

/* Config API - POST save event settings (host only) */
app.post('/api/config/save', (req, res) => {
    const eventId = (req.query.eventId || '').toUpperCase();
    if (!eventId) return res.status(400).json({ error: 'Event ID is required' });

    const { eventName, countdownTarget, shotLimit, enableUpload, enableDownload, customMessage, enableModeration, monetizationTier, sponsorLink, sponsorText } = req.body;
    
    db.run(
        'UPDATE events SET name = ?, release_time = ?, shot_limit = ?, enable_upload = ?, enable_download = ?, custom_message = ?, enable_moderation = ?, monetization_tier = ?, sponsor_link = ?, sponsor_text = ? WHERE id = ?',
        [eventName || 'My Event', countdownTarget || null, parseInt(shotLimit) || 25, parseInt(enableUpload), parseInt(enableDownload), customMessage || null, parseInt(enableModeration) || 0, monetizationTier || 'free', sponsorLink || null, sponsorText || null, eventId],
        (err) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            res.status(200).json({ status: 200, message: 'Configuration saved successfully.' });
        }
    );
});

/* Event stats API - per-guest breakdown */
app.get('/api/events/:eventId/stats', (req, res) => {
    const eventId = req.params.eventId.toUpperCase();
    db.all(
        `SELECT uploader_name, COUNT(*) as photo_count 
         FROM photos WHERE event_id = ? 
         GROUP BY uploader_name 
         ORDER BY photo_count DESC`,
        [eventId],
        (err, rows) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            db.get('SELECT COUNT(*) as total FROM photos WHERE event_id = ?', [eventId], (err2, countRow) => {
                res.json({
                    total: countRow ? countRow.total : 0,
                    guests: rows
                });
            });
        }
    );
});

/* Event delete */
app.delete('/api/events/:eventId', (req, res) => {
    const eventId = req.params.eventId.toUpperCase();
    // Delete all photos from DB
    db.run('DELETE FROM photos WHERE event_id = ?', [eventId], (err) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        // Delete the event
        db.run('DELETE FROM events WHERE id = ?', [eventId], (err2) => {
            if (err2) return res.status(500).json({ error: 'Database error' });
            // Try to delete files on disk
            const eventDir = path.join(__dirname, 'data', 'events', eventId);
            try {
                if (fs.existsSync(eventDir)) {
                    fs.rmSync(eventDir, { recursive: true, force: true });
                }
            } catch(e) {
                console.error('Could not delete event directory:', e);
            }
            res.json({ message: 'Event deleted successfully' });
        });
    });
});

/* Photo API endpoints */
app.get('/api/photos', (req, res) => {
    photosAPI.getPhotos(req, res);
});

/* Serve uploaded files for local storage */
app.use('/api/photos/download/:eventId', (req, res, next) => {
    const eventId = req.params.eventId;
    const eventDir = path.join(__dirname, 'data', 'events', eventId);
    express.static(eventDir)(req, res, next);
});

app.post('/api/photos', (req, res) => {
    photosAPI.createPhotos(req, res);
});

app.patch('/api/photos', (req, res) => {
    photosAPI.patchPhotos(req, res);
});

app.delete('/api/photos', (req, res) => {
    photosAPI.deletePhotos(req, res);
});

app.post('/api/photos/download', (req, res) => {
    downloadPhotosAPI.downloadPhotos(req, res);
});

/* Trailing slash redirects */
app.get('/:eventId/upload/', (req, res) => res.redirect('/' + req.params.eventId + '/upload'));
app.get('/:eventId/view/',   (req, res) => res.redirect('/' + req.params.eventId + '/view'));
app.get('/:eventId/manage/', (req, res) => res.redirect('/' + req.params.eventId + '/manage'));

/* 404 catch-all */
app.all('*', (req, res) => {
    console.log(`404 NOT FOUND: ${req.method} ${req.originalUrl}`);
    res.status(404).json({ status: 404, message: 'Not Found', details: 'Page not found.' });
});

/* Start server */
if (process.env.NODE_ENV !== 'test') {
    app.listen(port, '0.0.0.0', () => {
        const lanIp = getLanIp();
        console.log(`\n🎞  Lumina server started`);
        console.log(`   Local:    http://localhost:${port}`);
        console.log(`   Network:  http://${lanIp}:${port}`);
        console.log(`   Guest QR: http://${lanIp}:${port}/{eventId}/upload\n`);
    });
}

module.exports = app;
