const express = require('express');
const crypto = require('crypto');
const db = require('../db/database');
const { requireAuth } = require('../middleware/authMiddleware');

const router = express.Router();

// Generate a random 5-character event code (e.g. A9B2X)
function generateEventCode() {
    return crypto.randomBytes(3).toString('hex').toUpperCase().substring(0, 5);
}

// GET all events for the logged-in host
router.get('/', requireAuth, (req, res) => {
    db.all('SELECT * FROM events WHERE host_id = ? ORDER BY created_at DESC', [req.user.id], (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json({ events: rows });
    });
});

// POST create a new event
router.post('/', requireAuth, (req, res) => {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'Event name is required' });

    const eventId = generateEventCode();
    
    db.run(
        'INSERT INTO events (id, host_id, name) VALUES (?, ?, ?)',
        [eventId, req.user.id, name],
        function(err) {
            if (err) {
                // In the extremely rare case of a collision, we could retry, but for now just error
                if (err.message.includes('UNIQUE')) {
                    return res.status(500).json({ error: 'ID collision, please try again' });
                }
                return res.status(500).json({ error: 'Database error' });
            }
            res.status(201).json({ 
                message: 'Event created successfully', 
                event: { id: eventId, name, host_id: req.user.id }
            });
        }
    );
});

// GET single event info (Public, for guests to verify code)
router.get('/:id', (req, res) => {
    const eventId = req.params.id.toUpperCase();
    db.get('SELECT id, name, shot_limit, enable_upload, enable_download, release_time FROM events WHERE id = ?', [eventId], (err, event) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        if (!event) return res.status(404).json({ error: 'Event not found' });
        res.json({ event });
    });
});

module.exports = router;
