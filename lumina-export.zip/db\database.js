const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Ensure data directory exists
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = process.env.NODE_ENV === 'test' ? ':memory:' : path.join(dataDir, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        initializeSchema();
    }
});

function initializeSchema() {
    db.serialize(() => {
        // Users Table (Hosts)
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Events Table
        db.run(`
            CREATE TABLE IF NOT EXISTS events (
                id TEXT PRIMARY KEY,
                host_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                shot_limit INTEGER DEFAULT 25,
                enable_upload INTEGER DEFAULT 1,
                enable_download INTEGER DEFAULT 1,
                release_time DATETIME,
                custom_message TEXT,
                enable_moderation INTEGER DEFAULT 0,
                monetization_tier TEXT DEFAULT 'free',
                sponsor_link TEXT,
                sponsor_text TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (host_id) REFERENCES users(id)
            )
        `);
        // Migrate existing DBs
        db.run(`ALTER TABLE events ADD COLUMN custom_message TEXT`, () => {});
        db.run(`ALTER TABLE events ADD COLUMN enable_moderation INTEGER DEFAULT 0`, () => {});
        db.run(`ALTER TABLE events ADD COLUMN monetization_tier TEXT DEFAULT 'free'`, () => {});
        db.run(`ALTER TABLE events ADD COLUMN sponsor_link TEXT`, () => {});
        db.run(`ALTER TABLE events ADD COLUMN sponsor_text TEXT`, () => {});

        // Photos Table
        db.run(`
            CREATE TABLE IF NOT EXISTS photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT NOT NULL,
                filename TEXT NOT NULL,
                content_type TEXT NOT NULL,
                uploader_name TEXT,
                guest_email TEXT,
                note TEXT,
                meta_tags TEXT DEFAULT '[]',
                people_tags TEXT DEFAULT '[]',
                is_approved INTEGER DEFAULT 1,
                uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (event_id) REFERENCES events(id)
            )
        `);
        // Migrate existing DBs
        db.run(`ALTER TABLE photos ADD COLUMN guest_email TEXT`, () => {});
        db.run(`ALTER TABLE photos ADD COLUMN is_approved INTEGER DEFAULT 1`, () => {});
    });
}

module.exports = db;
